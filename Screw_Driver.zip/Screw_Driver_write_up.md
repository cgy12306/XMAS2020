# Screw Driver

---

1. 출제 의도 / 배경
   * 사용자는 드라이버의 DeviceIoControl을 통해 kernel에게 IRP 패킷을 보낼 수 있습니다.  만약 드라이버에 취약한 코드가 존재한다면 공격자는 악의적인 행위를 통해 DoS, LPE 등을 수행할 수 있습니다.
2. 문제 풀이
   - file에서 읽어온 값(역순)을 미리 세팅된 string과 xor 연산
   - 연산된 값과 사용자가 보낸 Inbuffer와 비교
   - 일치하게 되면 file에서 읽어온 값(정순)을 달팽이 배열 알고리즘 순서로 Inbuffer와 xor 연산
   - flag의 md5와 xor 연산된 값의 md5가 일치하면 flag를 output으로 출력

3. 익스플로잇 코드

```c
#include<stdio.h>
#include<string.h>
int main(){

    int x = 0, y = 0, i = 0, j = -1, sw = 1, cnt = 4, size = 5, z = 0;
    char string[30] = "\x73\x6b\x0c\x6a\x54\x0d\x52\x3f\x0c\x64\x6c\x2e\x65\x4a\x33\x0b\x43\x4e\x40\x26\x7f\x72\x1f\x68\x5b\x63\x34\x03\x3c";
    char string2[5][5]={0,};
    char buf[30] ={0,};
    char flag[30] = {0,};
    FILE *fp;

    fp = fopen("file", "r");

    fread(buf, 1, 29, fp);
    memcpy(buf, &"XMAS", 4);
    memcpy(string2[0], buf+4, 5);
    memcpy(string2[1], buf+9, 5);
    memcpy(string2[2], buf+14, 5);
    memcpy(string2[3], buf+19, 5);
    memcpy(string2[4], buf+24, 5);
    for (i = 0; i < 29; i++) {
		flag[i] = buf[28 - i] ^ string[i];
	}
    memcpy(flag, &"XMAS", 4);
    i = 0;
	while (1) {
		for (x = 0; x < size; x++) {
			j += sw;
			flag[cnt] = (flag[cnt] ^ string2[i][j]) + (char)z;
			cnt++;
			z++;
		}
		size -= 1;
		if (size <= 0) break;
		for (y = 0; y < size; y++) {
			i += sw;
			flag[cnt] = (flag[cnt] ^ string2[i][j]) + (char)z;
			cnt++;
			z++;
		}
		sw *= -1;
	}
    printf("%s", flag);

    return 0;
}
```

or

```c
#include<stdio.h>
#include<windows.h>
#include<conio.h>
#include<stdlib.h>
int main(int argc, char* argv[]) {

	HANDLE dhandle;

	WCHAR DeviceLink[] = L"\\\\.\\screw";

	DWORD inbuffersize = 30;
	DWORD outbuffersize = 30;
	char string[30] = "\x73\x6b\x0c\x6a\x54\x0d\x52\x3f\x0c\x64\x6c\x2e\x65\x4a\x33\x0b\x43\x4e\x40\x26\x7f\x72\x1f\x68\x5b\x63\x34\x03\x3c";
	char in[30] ={0,};
	char out[30] = {0,};
	char buf[30] = {0,};
	FILE *fp;
	
	fp = fopen("C:\\file", "r");
	fread(buf, 1, 29, fp);
	memcpy(buf, &"XMAS", 4);
	
	for (int i = 0; i < 29; i++) {
		in[i] = buf[28 - i] ^ string[i];
	}
	
	int ntstatus = 0;
    printf("inbuffer : %s\n", in);

	dhandle = CreateFileW(DeviceLink, GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	DeviceIoControl(dhandle, 0x222004, NULL, 0, NULL, 0, NULL, NULL);
    DeviceIoControl(dhandle, 0x222008, NULL, 0, NULL, 0, NULL, NULL);
    ntstatus = DeviceIoControl(dhandle, 0x222000, (LPVOID)in, inbuffersize, out, outbuffersize, NULL, NULL);

	CloseHandle(dhandle);

	printf("outbuffer : %s\n", out);
    return 0;
}
```





```input : @_@-Round_aNd_roUnd_@nD_r0uNd```

```flag : XMAS{Y0u_@r3_tH3_b35t_dRiv3r}```

